package yl_features;

import org.testng.annotations.Test;

public class YL_CheckOut {
  @Test
  public void f() {
	  
  }
}
