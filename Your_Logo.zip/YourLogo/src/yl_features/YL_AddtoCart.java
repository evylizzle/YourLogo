package yl_features;

import org.testng.annotations.Test;

public class YL_AddtoCart {
  @Test
  public void f() {
  }
}
