package yl_features;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class YL_CreateAccount {
	
	WebDriver driver;
	
	public void YL_CreateAccount(WebDriver driver){
		this.driver=driver;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	
	@Test
	public static void createAccount(WebDriver _driver) throws InterruptedException {
		
		//Codigo para acceder al form para crear un usuario nuevo
		_driver.findElement(By.xpath("//a[@class=\"login\"]")).click();
		llenarCampos(_driver, "//input[@id=\"email_create\"]", "test_YL@gmail.com");
		_driver.findElement(By.id("SubmitCreate")).click();
		Thread.sleep(5000);
		//Codigo de llenado form para crear un usuario nuevo
		_driver.findElement(By.xpath("//input[@id=\"id_gender1\"]")).click();
		llenarCampos(_driver, "//input[@id=\"customer_firstname\"]","Tester");
		llenarCampos(_driver, "//input[@id=\"customer_lastname\"]","Alvarado");
		llenarCampos(_driver, "//input[@id=\"email\"]","testeralvarado@gmail.com");
		llenarCampos(_driver, "//input[@id='passwd']","testeralvarado123");
		Thread.sleep(5000);
	}
	
	/*Aqu� se est� creando un metodo que escribe en los campos de inputs
	*Esto es para evitar codigo redundante*/
	public static void llenarCampos(WebDriver _driver, String xPath, String dato) {
		WebElement element = _driver.findElement(By.xpath(xPath));
		element.clear();
		element.sendKeys(dato);
	}
}
