package yl_features;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import yl_base.YL_Login;
import yl_drivers.YL_ChromeDriver;
import yl_support.YL_ReadUtility;

public class YL_ContactUs extends YL_ChromeDriver {

	@Test(dataProvider="DataTest")
	public void ContactUs(String email, String psw) throws InterruptedException {
		driver.findElement(By.id("contact-link")).click();
		driver.findElement(By.xpath("//option[@value='2']")).click();
		driver.findElement(By.id("email")).sendKeys(email);
		driver.findElement(By.id("id_order")).sendKeys(psw);
		driver.findElement(By.id("message")).sendKeys("x");
		Thread.sleep(5000);
	}
	
	@DataProvider
	public Object[][] DataTest() throws Exception {
        Object[][] testObjArray = YL_ReadUtility.getTableArray("C:\\Users\\christopher.carlos\\eclipse-workspace\\YourLogo\\resources\\data\\datausers.xlsx","Sheet1");
        return (testObjArray);
	}
	
	/* Llamar login
	 * @Test(priority=1)
	public void Login()
	{
		YL_Login login = new YL_Login(driver);
		login.run();
	}*/
}
