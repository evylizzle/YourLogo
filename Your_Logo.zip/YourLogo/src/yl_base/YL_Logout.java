package yl_base;

import org.testng.annotations.Test;

public class YL_Logout {
  @Test
  public void f() {
  }
}
