package yl_base;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class YL_Login {

	WebDriver driver;
	
	public YL_Login(WebDriver _driver) {
		this.driver = _driver;
	}
	
	public void run() {
		
	}
	
}
