package yl_drivers;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import yl_features.YL_ContactUs;
import yl_features.YL_CreateAccount;

import org.openqa.selenium.WebDriver;

public class YL_ChromeDriver {

	protected WebDriver driver;

	@BeforeClass
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\drivers\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php");
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	
	/*
	// Llamando al test case de Create Account
	@Test(description = "Create account reached", priority = 1)
	public void CreateAccount() throws InterruptedException {
		YL_CreateAccount yl_account = new YL_CreateAccount();
		yl_account.createAccount(driver);
	}

	// Llamando al test case de Contact Us
	@Test(description = "Contact us reached", priority = 2)
	public void ContactUs() throws InterruptedException {
		YL_ContactUs yl_contactus = new YL_ContactUs();
		yl_contactus.ContactUs(driver);
	}
	*/
}
